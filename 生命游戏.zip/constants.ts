// Visual Constants
export const CELL_SIZE = 20; // Base size of a cell in pixels at zoom 1.0

// Colors
export const BG_COLOR = '#ffffff';
export const LIVE_CELL_COLOR = '#000000';

// Grid Line Colors (Tailwind-like grays)
export const GRID_COLOR_L1 = '#e5e7eb'; // Level 1 (1x1) - Lightest
export const GRID_COLOR_L2 = '#9ca3af'; // Level 2 (10x10) - Medium
export const GRID_COLOR_L3 = '#4b5563'; // Level 3 (100x100) - Darkest

// Simulation
export const SIMULATION_SPEED_MS = 100;
export const REPLAY_SPEED_MS = 600; // 慢动作回放速度

// Zoom Constraints
export const MIN_ZOOM = 0.02; // Can zoom out very far
export const MAX_ZOOM = 5.0;  // Can zoom in closely

// Visibility Thresholds
// "Upward slide to shrink... to 1/2 size... show Level 2"
export const THRESHOLD_L1_HIDE = 0.2; // L1 grid disappears when zoom is below this (too dense)
export const THRESHOLD_L2_SHOW = 0.5; // L2 grid appears when zoom is below 0.5 (1/2 size of original)
export const THRESHOLD_L3_SHOW = 0.25; // L3 grid appears when zoom is below 0.25 (1/2 size of L2 appearance)