export type GridType = Set<string>;

export interface Viewport {
  offsetX: number;
  offsetY: number;
  zoom: number;
}

export interface GameState {
  grid: GridType;
  isRunning: boolean;
  generation: number;
}