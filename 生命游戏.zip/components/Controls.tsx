import React from 'react';
import { Play, Pause, Square, StepForward } from 'lucide-react';

interface ControlsProps {
  isRunning: boolean;
  onStart: () => void;
  onPause: () => void;
  onStop: () => void;
  onStep: () => void;
  generation: number;
}

export const Controls: React.FC<ControlsProps> = ({
  isRunning,
  onStart,
  onPause,
  onStop,
  onStep,
}) => {
  return (
    <div className="fixed bottom-12 left-0 right-0 flex items-center justify-center pointer-events-none z-40">
      <div className="flex items-center gap-4 md:gap-6 pointer-events-auto">
        {/* Step Button (Single Generation) */}
        <button
          onClick={onStep}
          disabled={isRunning}
          title="演化一代"
          className={`flex items-center gap-2 px-6 py-3 bg-white/80 backdrop-blur-sm border-2 border-gray-900/90 text-gray-900 text-lg font-semibold rounded-full transition-all active:scale-95 shadow-sm ${isRunning ? 'opacity-50 cursor-not-allowed' : 'hover:bg-white/95'}`}
        >
          <StepForward size={20} fill="currentColor" />
          单步
        </button>

        {/* Start/Pause Button */}
        {!isRunning ? (
          <button
            onClick={onStart}
            className="flex items-center gap-2 px-8 py-3 bg-black/80 backdrop-blur-sm text-white text-lg font-semibold rounded-full hover:bg-black/90 transition-all active:scale-95 shadow-lg"
          >
            <Play size={20} fill="currentColor" />
            开始
          </button>
        ) : (
          <button
            onClick={onPause}
            className="flex items-center gap-2 px-8 py-3 bg-gray-200/80 backdrop-blur-sm text-gray-900 text-lg font-semibold rounded-full hover:bg-gray-300/80 transition-all active:scale-95 shadow-lg"
          >
            <Pause size={20} fill="currentColor" />
            暂停
          </button>
        )}

        {/* Stop Button */}
        <button
          onClick={onStop}
          className="flex items-center gap-2 px-6 py-3 bg-white/80 backdrop-blur-sm border-2 border-red-500/90 text-red-500 text-lg font-semibold rounded-full hover:bg-red-50/90 transition-all active:scale-95 shadow-sm"
        >
          <Square size={20} fill="currentColor" />
          停止
        </button>
      </div>
    </div>
  );
};