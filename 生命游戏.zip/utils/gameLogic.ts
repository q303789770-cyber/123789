import { GridType } from '../types';

export const createEmptyGrid = (): GridType => {
  return new Set<string>();
};

// 辅助函数：判断两个集合是否相等
export const areSetsEqual = (a: Set<string>, b: Set<string>): boolean => {
  if (a.size !== b.size) return false;
  for (const item of a) {
    if (!b.has(item)) return false;
  }
  return true;
};

// 生成网格的唯一签名（坐标排序后的字符串），用于检测循环
export const gridSignature = (grid: GridType): string => {
  return Array.from(grid).sort().join('|');
};

export const computeNextGeneration = (currentCells: GridType): GridType => {
  const neighborCounts = new Map<string, number>();
  const nextCells = new Set<string>();

  // 1. Calculate neighbor counts for all active cells and their neighbors
  // This is efficient for sparse grids (infinite world)
  for (const key of currentCells) {
    const [x, y] = key.split(',').map(Number);

    // Check all 8 neighbors around a live cell
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        if (dx === 0 && dy === 0) continue;

        const neighborKey = `${x + dx},${y + dy}`;
        neighborCounts.set(neighborKey, (neighborCounts.get(neighborKey) || 0) + 1);
      }
    }
  }

  // 2. Apply Game of Life Rules
  for (const [key, count] of neighborCounts) {
    const isAlive = currentCells.has(key);

    // Logic 1: Alive + 2 or 3 -> Alive
    if (isAlive && (count === 2 || count === 3)) {
      nextCells.add(key);
    }
    // Logic 2: Alive + >=4 -> Dead (Implicitly removed)
    // Logic 3: Dead + 3 -> Alive
    else if (!isAlive && count === 3) {
      nextCells.add(key);
    }
    // Implicit: Alive + < 2 -> Dead
  }

  return nextCells;
};

// Calculate the bounding box of all live cells to center the camera
export const getBoundingBox = (cells: GridType) => {
  if (cells.size === 0) return null;

  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;

  // Optimizing: We don't need to check every single cell if there are millions,
  // but for a typical game of life session, iterating the Set is fast enough.
  for (const key of cells) {
    const [x, y] = key.split(',').map(Number);
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
  }

  return { minX, maxX, minY, maxY };
};