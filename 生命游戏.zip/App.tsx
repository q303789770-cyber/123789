import React, { useState, useCallback, useRef, useEffect } from 'react';
import { createEmptyGrid, computeNextGeneration, getBoundingBox } from './utils/gameLogic';
import { 
  SIMULATION_SPEED_MS, 
  REPLAY_SPEED_MS,
  CELL_SIZE, 
  MIN_ZOOM, 
  MAX_ZOOM, 
  BG_COLOR, 
  LIVE_CELL_COLOR,
  GRID_COLOR_L1,
  GRID_COLOR_L2,
  GRID_COLOR_L3,
  THRESHOLD_L1_HIDE,
  THRESHOLD_L2_SHOW,
  THRESHOLD_L3_SHOW
} from './constants';
import { Controls } from './components/Controls';
import { GridType, Viewport } from './types';
import { Info, RotateCcw, Lock, Unlock } from 'lucide-react';

function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Game State
  const [grid, setGrid] = useState<GridType>(createEmptyGrid());
  const [isRunning, setIsRunning] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [generation, setGeneration] = useState(0);

  // View Settings
  // Default to false (Free View) as requested
  const [isAutoTracking, setIsAutoTracking] = useState(false);

  // Viewport State
  const [viewport, setViewport] = useState<Viewport>({ 
    offsetX: 0, 
    offsetY: 0, 
    zoom: 1 
  });
  
  // Refs for access inside closures/callbacks without triggering re-renders
  const gridRef = useRef(grid);
  gridRef.current = grid;
  
  const viewportRef = useRef(viewport);
  viewportRef.current = viewport; 

  const isAutoTrackingRef = useRef(isAutoTracking);
  isAutoTrackingRef.current = isAutoTracking;

  const replayBufferRef = useRef<GridType[]>([]); // For visual replay (actual data)

  const isDragging = useRef(false);
  const lastMousePos = useRef({ x: 0, y: 0 });
  const startDragPos = useRef({ x: 0, y: 0 });
  const lastPinchDist = useRef<number | null>(null);

  // Helper to stop game
  const triggerGameOver = useCallback((finalGrid?: GridType) => {
    setIsRunning(false);
    
    // Ensure the very last state is added to the replay buffer
    if (finalGrid) {
        replayBufferRef.current.push(new Set(finalGrid)); // Clone check
        if (replayBufferRef.current.length > 6) {
            replayBufferRef.current.shift();
        }
    }
    
    setIsGameOver(true);
  }, []);

  // --- Replay Loop (Run ONLY when Game Over) ---
  useEffect(() => {
    if (!isGameOver) return;

    let frameIndex = 0;
    const buffer = replayBufferRef.current;
    
    // If buffer is empty (e.g. manual stop with no generations), do nothing
    if (buffer.length === 0) return;

    const intervalId = setInterval(() => {
      // Cycle through the buffer
      const nextFrame = buffer[frameIndex % buffer.length];
      setGrid(nextFrame);
      frameIndex++;
    }, REPLAY_SPEED_MS);

    return () => clearInterval(intervalId);
  }, [isGameOver]);

  // --- Game Loop (Simulation & Auto-Tracking) ---
  useEffect(() => {
    if (!isRunning) return;

    let animationFrameId: number;
    let lastTime = 0;

    const gameLoop = (timestamp: number) => {
      if (timestamp - lastTime >= SIMULATION_SPEED_MS) {
        const currentGrid = gridRef.current;
        
        // 0. Save current state to Replay Buffer (Deep Copy)
        replayBufferRef.current.push(new Set(currentGrid));
        if (replayBufferRef.current.length > 6) {
          replayBufferRef.current.shift();
        }

        // 1. Compute Logic
        const nextGrid = computeNextGeneration(currentGrid);
        
        // --- GAME OVER CHECKS ---
        
        // Check A: Extinction (Only stop if everyone dies)
        if (nextGrid.size === 0) {
          setGrid(nextGrid);
          setGeneration(g => g + 1);
          triggerGameOver(nextGrid);
          return; 
        }

        // --- Update State ---
        setGrid(nextGrid);
        setGeneration(g => g + 1);
        lastTime = timestamp;

        // 2. Auto-Tracking Logic
        // Only run if Auto Tracking is enabled
        if (isAutoTrackingRef.current) {
          const bbox = getBoundingBox(nextGrid);
          if (bbox) {
            const canvas = canvasRef.current;
            if (canvas) {
              const currentVP = viewportRef.current;
              
              const centerX = ((bbox.minX + bbox.maxX + 1) / 2) * CELL_SIZE;
              const centerY = ((bbox.minY + bbox.maxY + 1) / 2) * CELL_SIZE;
              
              const viewW = canvas.width;
              const viewH = canvas.height;
              
              const targetOffsetX = centerX - (viewW / 2 / currentVP.zoom);
              const targetOffsetY = centerY - (viewH / 2 / currentVP.zoom);

              const factor = 0.1;
              const newOffsetX = currentVP.offsetX + (targetOffsetX - currentVP.offsetX) * factor;
              const newOffsetY = currentVP.offsetY + (targetOffsetY - currentVP.offsetY) * factor;

              if (Math.abs(newOffsetX - currentVP.offsetX) > 0.5 || Math.abs(newOffsetY - currentVP.offsetY) > 0.5) {
                setViewport(prev => ({ ...prev, offsetX: newOffsetX, offsetY: newOffsetY }));
              }
            }
          }
        }
      }
      animationFrameId = requestAnimationFrame(gameLoop);
    };

    animationFrameId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isRunning, triggerGameOver]);

  // --- Rendering Loop ---
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: false }); 
    if (!ctx) return;

    // Clear Screen
    ctx.fillStyle = BG_COLOR;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const { offsetX, offsetY, zoom } = viewport;
    
    // Setup Transform
    ctx.save();
    ctx.scale(zoom, zoom);
    ctx.translate(-offsetX, -offsetY);

    // --- Draw Grid Lines ---
    const viewWidth = canvas.width / zoom;
    const viewHeight = canvas.height / zoom;
    
    const startX = offsetX;
    const endX = offsetX + viewWidth;
    const startY = offsetY;
    const endY = offsetY + viewHeight;

    const drawGridLayer = (stepSize: number, color: string, lineWidth: number) => {
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = lineWidth / zoom; 

      const firstLineX = Math.floor(startX / stepSize) * stepSize;
      const firstLineY = Math.floor(startY / stepSize) * stepSize;

      for (let x = firstLineX; x <= endX; x += stepSize) {
        ctx.moveTo(x, startY);
        ctx.lineTo(x, endY);
      }
      for (let y = firstLineY; y <= endY; y += stepSize) {
        ctx.moveTo(startX, y);
        ctx.lineTo(endX, y);
      }
      ctx.stroke();
    };

    if (zoom <= THRESHOLD_L3_SHOW) {
      drawGridLayer(CELL_SIZE * 100, GRID_COLOR_L3, 2.0);
    }
    if (zoom <= THRESHOLD_L2_SHOW) {
      drawGridLayer(CELL_SIZE * 10, GRID_COLOR_L2, 1.5);
    }
    if (zoom > THRESHOLD_L1_HIDE) {
      drawGridLayer(CELL_SIZE, GRID_COLOR_L1, 0.5);
    }

    // --- Draw Live Cells ---
    ctx.fillStyle = LIVE_CELL_COLOR;
    
    const cullMargin = CELL_SIZE;
    
    for (const key of grid) {
      const [gx, gy] = key.split(',').map(Number);
      const worldX = gx * CELL_SIZE;
      const worldY = gy * CELL_SIZE;

      if (
        worldX >= startX - cullMargin && 
        worldX <= endX && 
        worldY >= startY - cullMargin && 
        worldY <= endY
      ) {
        const gap = zoom > 0.5 ? 1 : 0;
        ctx.fillRect(worldX, worldY, CELL_SIZE - gap, CELL_SIZE - gap);
      }
    }

    ctx.restore();
  }, [grid, viewport]);

  // --- Resize Handling ---
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
        setViewport(prev => ({ ...prev }));
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // --- Input Handlers ---
  const toggleCellAt = (clientX: number, clientY: number) => {
    if (isGameOver || isRunning) return; 
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    const currentVP = viewportRef.current;
    
    const worldX = (x / currentVP.zoom) + currentVP.offsetX;
    const worldY = (y / currentVP.zoom) + currentVP.offsetY;

    const gridX = Math.floor(worldX / CELL_SIZE);
    const gridY = Math.floor(worldY / CELL_SIZE);
    const key = `${gridX},${gridY}`;

    setGrid(prev => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };

  const handleWheel = (e: React.WheelEvent) => {
    const scaleFactor = 1.1;
    const isZoomIn = e.deltaY > 0; 
    
    const newZoomRaw = isZoomIn ? viewport.zoom * scaleFactor : viewport.zoom / scaleFactor;
    const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, newZoomRaw));
    
    const rect = canvasRef.current!.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const worldMouseX = (mouseX / viewport.zoom) + viewport.offsetX;
    const worldMouseY = (mouseY / viewport.zoom) + viewport.offsetY;

    const newOffsetX = worldMouseX - (mouseX / newZoom);
    const newOffsetY = worldMouseY - (mouseY / newZoom);

    setViewport({
      offsetX: newOffsetX,
      offsetY: newOffsetY,
      zoom: newZoom
    });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    lastMousePos.current = { x: e.clientX, y: e.clientY };
    startDragPos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging.current) {
      const dx = e.clientX - lastMousePos.current.x;
      const dy = e.clientY - lastMousePos.current.y;
      
      setViewport(prev => ({
        ...prev,
        offsetX: prev.offsetX - (dx / prev.zoom),
        offsetY: prev.offsetY - (dy / prev.zoom)
      }));

      lastMousePos.current = { x: e.clientX, y: e.clientY };
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    isDragging.current = false;
    const dist = Math.hypot(e.clientX - startDragPos.current.x, e.clientY - startDragPos.current.y);
    if (dist < 5) {
      toggleCellAt(e.clientX, e.clientY);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      isDragging.current = true;
      lastMousePos.current = { x: t.clientX, y: t.clientY };
      startDragPos.current = { x: t.clientX, y: t.clientY };
    } else if (e.touches.length === 2) {
      isDragging.current = false; 
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      lastPinchDist.current = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 1 && isDragging.current) {
      const t = e.touches[0];
      const dx = t.clientX - lastMousePos.current.x;
      const dy = t.clientY - lastMousePos.current.y;
      
      const currentVP = viewportRef.current;
      setViewport({
        ...currentVP,
        offsetX: currentVP.offsetX - (dx / currentVP.zoom),
        offsetY: currentVP.offsetY - (dy / currentVP.zoom)
      });
      
      lastMousePos.current = { x: t.clientX, y: t.clientY };
    } else if (e.touches.length === 2 && lastPinchDist.current !== null) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const currentDist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);
      
      const currentVP = viewportRef.current;
      
      const distRatio = currentDist / lastPinchDist.current;
      const newZoomRaw = currentVP.zoom * distRatio;
      const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, newZoomRaw));
      
      const centerX = (t1.clientX + t2.clientX) / 2;
      const centerY = (t1.clientY + t2.clientY) / 2;
      
      const rect = canvasRef.current!.getBoundingClientRect();
      const screenX = centerX - rect.left;
      const screenY = centerY - rect.top;
      
      const worldX = (screenX / currentVP.zoom) + currentVP.offsetX;
      const worldY = (screenY / currentVP.zoom) + currentVP.offsetY;
      
      const newOffsetX = worldX - (screenX / newZoom);
      const newOffsetY = worldY - (screenY / newZoom);

      setViewport({
        zoom: newZoom,
        offsetX: newOffsetX,
        offsetY: newOffsetY
      });
      
      lastPinchDist.current = currentDist;
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    lastPinchDist.current = null;
    if (isDragging.current && e.changedTouches.length > 0 && e.touches.length === 0) {
      const t = e.changedTouches[0];
      const dist = Math.hypot(t.clientX - startDragPos.current.x, t.clientY - startDragPos.current.y);
      if (dist < 10) {
        toggleCellAt(t.clientX, t.clientY);
      }
    }
    if (e.touches.length === 0) {
      isDragging.current = false;
    }
  };

  // --- Controls Handlers ---
  const handleStart = () => {
    if (grid.size === 0) return; 
    setIsRunning(true);
    setIsGameOver(false);
    replayBufferRef.current = [new Set(grid)]; // Init replay buffer
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleStop = () => {
    setIsRunning(false);
    setIsGameOver(false);
    setGrid(createEmptyGrid());
    setGeneration(0);
    replayBufferRef.current = [];
    setViewport({ offsetX: -window.innerWidth / 2 / CELL_SIZE * 20, offsetY: -window.innerHeight / 2 / CELL_SIZE * 20, zoom: 1 });
  };
  
  const handleReload = () => {
    handleStop();
  };

  const handleStep = () => {
    const next = computeNextGeneration(grid);
    if (next.size === 0) {
      setGrid(next);
      setGeneration(g => g + 1);
      triggerGameOver(next);
      return;
    }
    setGrid(next);
    setGeneration(prev => prev + 1);
  };

  return (
    <div className="fixed inset-0 bg-gray-50 flex flex-col font-sans overflow-hidden">
      
      {/* Header (Overlay) */}
      <header className="absolute top-0 left-0 right-0 z-20 bg-white/90 backdrop-blur-sm border-b border-gray-200 px-6 py-4 flex flex-col md:flex-row items-center justify-between shadow-sm pointer-events-auto transition-opacity duration-300 gap-2 md:gap-0" style={{ opacity: isGameOver ? 0.3 : 1 }}>
        <div className="flex items-center gap-4">
          <h1 className="text-2xl font-bold tracking-tight text-gray-900 flex items-center gap-2 select-none">
            二蛋生命游戏8.0 <span className="hidden md:inline text-xs font-normal text-gray-500 bg-gray-100 px-2 py-1 rounded-full border border-gray-200">无限世界</span>
          </h1>
          
          {/* View Toggle Button */}
          <button
            onClick={() => setIsAutoTracking(!isAutoTracking)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-medium rounded-full transition-colors border border-gray-200"
            title={isAutoTracking ? "点击切换为自由视角 (手动拖拽)" : "点击切换为锁定视角 (自动跟随)"}
          >
            {isAutoTracking ? <Lock size={14} /> : <Unlock size={14} />}
            <span>{isAutoTracking ? '锁定视角' : '自由视角'}</span>
          </button>
        </div>

        <div className="flex items-center gap-4 text-sm text-gray-500 select-none">
          <div className="flex items-center gap-1"><Info size={16}/> <span className="hidden sm:inline">滚轮/双指缩放 · 拖拽移动 · 点击生成</span><span className="sm:hidden">缩放 · 移动 · 点击</span></div>
        </div>
      </header>

      {/* Canvas World */}
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        // Removed heavy opacity/blur during Game Over to keep cells visible
        className={`block touch-none cursor-crosshair active:cursor-grabbing w-full h-full transition-all duration-1000 ${isGameOver ? 'opacity-100' : 'opacity-100'}`}
      />

      {/* Initial Hint */}
      {generation === 0 && grid.size === 0 && !isGameOver && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <p className="text-4xl md:text-6xl font-bold text-gray-900 opacity-10 select-none tracking-widest whitespace-nowrap animate-pulse">
            点击空白格子创造生命
          </p>
        </div>
      )}

      {/* --- Dynamic Status Text / Game Over Screen --- */}
      <div 
        className={`fixed z-50 pointer-events-none flex flex-col items-center justify-center transition-all duration-1000 ease-in-out
          ${isGameOver 
            ? 'top-32 left-0 right-0' // Game Over: Move up, not full screen
            : 'bottom-4 left-0 right-0' // Normal: Bottom position
          }
        `}
      >
        <div className="flex flex-col items-center gap-4">
          {isGameOver && (
            <h2 className="text-4xl font-black text-red-500/80 mb-1 tracking-tighter animate-in fade-in zoom-in duration-500 select-none">
              GAME OVER
            </h2>
          )}
          
          <div 
            className={`px-6 py-2 rounded-full shadow-sm select-none transition-all duration-1000 border text-center whitespace-nowrap
              ${isGameOver 
                ? 'bg-black/80 backdrop-blur-sm text-white text-xl font-semibold px-8 py-3 border-black shadow-lg' // Smaller, less obstructive style
                : 'bg-white/80 backdrop-blur-md text-gray-600 text-sm font-medium border-gray-100/50 scale-100' 
              }
            `}
          >
            您的子民繁殖了 {generation} 代
            {isGameOver && <span className="block text-xs font-normal opacity-75 mt-1">慢动作回放中...</span>}
          </div>

          {isGameOver && (
            <button
              onClick={handleReload}
              className="pointer-events-auto mt-2 px-8 py-3 bg-red-600/90 hover:bg-red-700 text-white text-lg font-bold rounded-full shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 animate-in fade-in slide-in-from-bottom-4 duration-700"
            >
              <RotateCcw size={20} />
              再来一次
            </button>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className={`transition-all duration-500 ${isGameOver ? 'opacity-0 translate-y-20' : 'opacity-100 translate-y-0'}`}>
        <Controls
          isRunning={isRunning}
          onStart={handleStart}
          onPause={handlePause}
          onStop={handleStop}
          onStep={handleStep}
          generation={generation}
        />
      </div>
    </div>
  );
}

export default App;